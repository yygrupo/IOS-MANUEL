//
//  WRegisterInteractor.swift
//  Worcipe
//
//  Created by Manuel Alejandro on 14/09/16.
//
//

import Foundation

class WRegisterInteractor: NSObject
{
    weak var presenter: WRegisterPresenter?
    var dataManager: WRegisterDataManager?
}
