//
//  WRegisterDataManager.swift
//  Worcipe
//
//  Created by Manuel Alejandro on 14/09/16.
//
//

import Foundation

class WRegisterDataManager: NSObject
{

}
