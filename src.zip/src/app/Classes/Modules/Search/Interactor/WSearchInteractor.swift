//
//  WSearchInteractor.swift
//  Worcipe
//
//  Created by Manuel Alejandro on 13/09/16.
//
//

import Foundation

class WSearchInteractor: NSObject
{
    weak var presenter: WSearchPresenter?
    var dataManager: WSearchDataManager?
}
