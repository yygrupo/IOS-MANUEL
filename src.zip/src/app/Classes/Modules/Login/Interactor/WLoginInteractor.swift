//
//  WLoginInteractor.swift
//  Worcipe
//
//  Created by Manuel Alejandro on 14/09/16.
//
//

import Foundation

class WLoginInteractor: NSObject
{
    weak var presenter: WLoginPresenter?
    var dataManager: WLoginDataManager?
}
