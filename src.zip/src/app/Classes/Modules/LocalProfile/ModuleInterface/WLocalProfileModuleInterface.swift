//
//  WLocalProfileModuleInterface.swift
//  Worcipe
//
//  Created by Manuel Alejandro on 19/09/16.
//
//

import Foundation

protocol WLocalProfileModuleInterface
{
    func updateView()
}

protocol WLocalProfileModuleDelegate
{

}
