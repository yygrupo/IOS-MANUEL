//
//  WMenuInteractor.swift
//  Worcipe
//
//  Created by Manuel Alejandro on 13/09/16.
//
//

import Foundation

class WMenuInteractor: NSObject
{
    weak var presenter: WMenuPresenter?
    var dataManager: WMenuDataManager?
}
