//
//  WMenuModuleInterface.swift
//  Worcipe
//
//  Created by Manuel Alejandro on 13/09/16.
//
//

import Foundation

protocol WMenuModuleInterface
{
    func presentViewControllerAtIndex(index: Int)
}

protocol WMenuModuleDelegate
{

}
