//
//  WRateInteractor.swift
//  Worcipe
//
//  Created by Manuel Alejandro on 13/09/16.
//
//

import Foundation

class WRateInteractor: NSObject
{
    weak var presenter: WRatePresenter?
    var dataManager: WRateDataManager?
}
