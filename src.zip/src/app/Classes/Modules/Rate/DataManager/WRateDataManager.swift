//
//  WRateDataManager.swift
//  Worcipe
//
//  Created by Manuel Alejandro on 13/09/16.
//
//

import Foundation

class WRateDataManager: NSObject
{

}
