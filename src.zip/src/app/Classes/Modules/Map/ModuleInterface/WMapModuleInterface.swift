//
//  WMapModuleInterface.swift
//  Worcipe
//
//  Created by Manuel Alejandro on 14/09/16.
//
//

import Foundation

protocol WMapModuleInterface
{
    func updateView()
    func showLocalProfile(local: WLocal)
}

protocol WMapModuleDelegate
{

}
