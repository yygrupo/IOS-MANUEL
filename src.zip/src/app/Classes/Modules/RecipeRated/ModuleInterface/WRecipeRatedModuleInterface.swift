//
//  WRecipeRatedModuleInterface.swift
//  Worcipe
//
//  Created by Manuel Alejandro on 23/09/16.
//
//

import Foundation

protocol WRecipeRatedModuleInterface
{
    func updateView()
    func presentRecipeDetail(recipe: WRecipe)
}

protocol WRecipeRatedModuleDelegate
{

}
