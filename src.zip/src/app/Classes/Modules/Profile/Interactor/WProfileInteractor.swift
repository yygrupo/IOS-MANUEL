//
//  WProfileInteractor.swift
//  Worcipe
//
//  Created by Manuel Alejandro on 14/09/16.
//
//

import Foundation

class WProfileInteractor: NSObject
{
    weak var presenter: WProfilePresenter?
    var dataManager: WProfileDataManager?
}
