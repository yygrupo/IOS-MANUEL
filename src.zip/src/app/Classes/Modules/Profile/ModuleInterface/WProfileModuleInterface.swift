//
//  WProfileModuleInterface.swift
//  Worcipe
//
//  Created by Manuel Alejandro on 14/09/16.
//
//

import Foundation

protocol WProfileModuleInterface
{

}

protocol WProfileModuleDelegate
{

}
