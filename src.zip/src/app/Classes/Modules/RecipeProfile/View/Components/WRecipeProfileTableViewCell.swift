//
//  WRecipeProfileTableViewCell.swift
//  app
//
//  Created by male on 9/24/16.
//  Copyright © 2016 Manuel Alejandro. All rights reserved.
//

import UIKit

class WRecipeProfileTableViewCell: UITableViewCell {
    
    @IBOutlet weak var imageViewInfo: UIImageView!
    @IBOutlet weak var labelInfo: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
