//
//  NSManagedRecipe.swift
//  app
//
//  Created by male on 9/24/16.
//  Copyright © 2016 Manuel Alejandro. All rights reserved.
//

import Foundation
import CoreData

@objc(NSManagedRecipe)
class NSManagedRecipe: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
